import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';

import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import LandingPage from './components/LandingPage';
import { ILandingPageProps } from './components/ILandingPageProps';

export interface ILandingPageWebPartProps {
  description: string;
}

export default class LandingPageWebPart extends BaseClientSideWebPart<ILandingPageWebPartProps> {



  public render(): void {
    const element: React.ReactElement<ILandingPageProps> = React.createElement(
      LandingPage,
      {
        description: this.properties.description,

      }
    );

    ReactDom.render(element, this.domElement);
  }



  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }


}

