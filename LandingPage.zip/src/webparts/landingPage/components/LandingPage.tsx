import * as React from 'react';
import type { ILandingPageProps } from './ILandingPageProps';

export default class LandingPage extends React.Component<ILandingPageProps, {}> {
  public render(): React.ReactElement<ILandingPageProps> {


    return (
      <>
      </>
    );
  }
}
