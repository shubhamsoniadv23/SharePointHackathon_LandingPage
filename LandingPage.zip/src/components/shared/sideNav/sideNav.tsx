import React from 'react';

type Props = {};

const SideNav = (props: Props) => {
    return (
        <div>SideNav</div>
    );
};

export default SideNav;