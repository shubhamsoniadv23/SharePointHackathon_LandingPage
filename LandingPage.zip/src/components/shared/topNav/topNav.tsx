import React from "react";

type Props = {};

const TopNav = (props: Props) => {
  return <div>TopNav</div>;
};

export default TopNav;
