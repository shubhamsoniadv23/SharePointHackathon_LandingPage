import React from 'react'

type Props = {}

const Loader = (props: Props) => {
  return (
    <div>Loading....</div>
  )
}

export default Loader;


