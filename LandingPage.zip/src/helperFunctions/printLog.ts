// import { BASE_URL, FRONTEND_URL } from "../constants/constant";

// export function printLog(...args: any[]) {
//   const serverUrl = import.meta.env.VITE_SERVER_URL;
//   // console.log("server url", serverUrl, FRONTEND_URL, serverUrl == FRONTEND_URL);
//   if (serverUrl == FRONTEND_URL) {
//     console.log(...args);
//   } else {
//     console.log(null);
//   }
// }
